# AI Receptionist Agency Vault
Open [[Start Here]]. Adapted from the Vaultorial CRM template, whose original files and MIT license statement are preserved under Archive/Original template.

This vault provides agency records, operating drafts and dynamic queries. It is not a running phone service. No real customers have been added. Dataview must be installed and enabled for query rendering; Templates and Bases are used for note creation and editable tables.
