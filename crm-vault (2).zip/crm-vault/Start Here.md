# AI Receptionist Agency — Start Here

Your working hub for selling and delivering an AI receptionist service to independent London car detailers, mobile valeters and vehicle tinting shops.

Open [[CRM Dashboard]] each day. Start with [[Agency/Launch Checklist|Launch Checklist]].

## Your assistant
Use [[Agency/Assistant Brief|Assistant Brief]] to brief ChatGPT on this vault. Tell it what happened in plain English: “I called this business; they want a demo next Tuesday.” It can organise the notes, draft a response and identify the next action. Dates and facts must be grounded in what you actually know.

This ZIP is a snapshot. ChatGPT cannot see subsequent changes in your local Obsidian automatically. Upload the latest vault when you want it reviewed or edited. Obsidian and these notes do not answer phone calls, send messages or book appointments themselves.

## First use
1. Extract this ZIP into a new folder so the old fictional files do not remain in your live folders.
2. Open the extracted `crm-vault` folder as a vault in Obsidian.
3. Install and enable Dataview if it is not installed. This ZIP does not bundle the plugin.
4. Open [[CRM Dashboard]] in reading view.
5. Create a company note in Companies using the Company template; add a contact only when known, then add a Deal.
6. After a real call, add an Interaction and update the deal's next action and follow-up date.

## Navigation
- [[Agency/Offer and Pricing|Offer and Pricing]]
- [[Agency/Sales Playbook|Sales Playbook]]
- [[Agency/Client Onboarding|Client Onboarding]]
- [[Agency/Receptionist Instructions|Receptionist Instructions]]
- [[Agency/Demo Test Plan|Demo Test Plan]]
- [[Agency/System Register|System Register]]
- [[Agency/Session Log|Session Log]]
- [[Pipeline.base|Editable pipeline]]

Original files are preserved under Archive/Original template. The active CRM contains no invented customers, payments, completed calls or bookings.
