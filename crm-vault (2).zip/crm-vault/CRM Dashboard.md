# Agency Dashboard
[[Start Here]] · [[Agency/Launch Checklist|Launch checklist]] · [[Pipeline.base|Pipeline]] · [[Agency/Sales Playbook|Sales scripts]]

Empty tables mean no real records have been added yet. All money is GBP. Potential deals and active subscriptions are reported separately; neither is proof of payment.

## Overdue and next seven days
```dataview
TABLE WITHOUT ID file.link AS "Deal", company AS "Business", next_action AS "Next action", next_follow_up AS "Due"
FROM "Deals"
WHERE stage != "won" AND stage != "lost" AND next_follow_up AND next_follow_up <= date(today) + dur(7 days)
SORT next_follow_up ASC
```

## Open deals missing a next action or date
```dataview
TABLE WITHOUT ID file.link AS "Deal", stage AS "Stage", next_action AS "Action", next_follow_up AS "Due"
FROM "Deals"
WHERE stage != "won" AND stage != "lost" AND (!next_action OR !next_follow_up)
```

## Sales pipeline — potential fees, not revenue
```dataview
TABLE WITHOUT ID key AS "Stage", length(rows) AS "Deals", sum(rows.setup_fee_gbp) AS "Setup £", sum(rows.monthly_fee_gbp) AS "Potential monthly £"
FROM "Deals"
WHERE stage != "won" AND stage != "lost"
GROUP BY stage
```

## Active subscriptions
```dataview
TABLE WITHOUT ID file.link AS "Client", monthly_fee_gbp AS "Monthly £", go_live_date AS "Live since", next_review AS "Review"
FROM "Clients"
WHERE status = "active"
SORT next_review ASC
```

## Contracted monthly recurring fees
```dataview
TABLE WITHOUT ID length(rows) AS "Active clients", sum(rows.monthly_fee_gbp) AS "Monthly recurring £"
FROM "Clients"
WHERE status = "active"
GROUP BY status
```

## Open tasks
```dataview
TASK
FROM "Agency" OR "Interactions" OR "Clients"
WHERE !completed
GROUP BY file.link
```

## Incoming calls needing action
```dataview
TABLE WITHOUT ID file.link AS "Call", company AS "Business", outcome AS "Outcome", next_action AS "Action"
FROM "Call Logs"
WHERE needs_follow_up = true
SORT date DESC
```

## Recent interactions
```dataview
TABLE WITHOUT ID file.link AS "Interaction", company AS "Business", channel AS "Channel", outcome AS "Outcome"
FROM "Interactions"
SORT date DESC
LIMIT 10
```
