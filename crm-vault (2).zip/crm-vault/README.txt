Extract this ZIP into a new folder. Open the crm-vault folder in Obsidian, then open Start Here.md. Do not merge over the original sample vault: that could retain fictional records in live folders.
