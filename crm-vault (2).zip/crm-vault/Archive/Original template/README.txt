CRM Vault — Obsidian Template
=============================

An Obsidian template by Vaultorial.

How to install:
  1. Unzip this file.
  2. In Obsidian, choose "Open folder as vault" and select the "crm-vault" folder.
  3. Open "Start Here.md" inside the vault and follow the steps.

Template page:  https://vaultorial.com/obsidian-crm/
More templates: https://vaultorial.com/
License: MIT (see README.md inside the vault)

Vaultorial is not affiliated with Obsidian (Dynalist Inc.).
