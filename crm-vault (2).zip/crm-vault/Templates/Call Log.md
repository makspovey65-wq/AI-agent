---
type: call
date: {{date:YYYY-MM-DD}}
time:
timezone: Europe/London
company:
caller_name:
callback_number:
service:
requested_slot:
outcome: unresolved
booking_reference:
needs_follow_up: true
next_action:
---
# {{title}}

## Summary

## Verified outcome

## Follow-up

Do not mark a booking confirmed without a successful booking-system result.
