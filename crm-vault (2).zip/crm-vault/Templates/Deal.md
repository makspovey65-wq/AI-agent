---
type: deal
company:
contact:
stage: lead
setup_fee_gbp: 299
monthly_fee_gbp: 40
next_action:
next_follow_up:
demo_at:
close_date:
lost_reason:
---
# {{title}}

## Need and fit

## Scope and objections

## Decision history
