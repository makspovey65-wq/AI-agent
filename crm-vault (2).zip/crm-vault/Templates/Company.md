---
type: company
industry:
website:
business_phone:
area:
source_url:
verified_on:
do_not_contact: false
---
# {{title}}

## Business notes

## People
```dataview
TABLE role, phone, email FROM "Contacts" AND [[]]
```
## Deals
```dataview
TABLE stage, setup_fee_gbp, monthly_fee_gbp, next_action FROM "Deals" AND [[]]
```
