---
type: client
company:
deal:
status: onboarding
setup_fee_gbp: 299
monthly_fee_gbp: 40
included_minutes:
setup_payment_status: unknown
subscription_payment_status: unknown
go_live_date:
next_review:
timezone: Europe/London
---
# {{title}}

## Approved business profile
Greeting, hours, address/service area, services, prices and durations:

## Booking and escalation rules

## Systems and non-secret references

## Acceptance evidence

## Onboarding tasks
- [ ] Approve business knowledge and service scope.
- [ ] Agree pricing, allowance and terms.
- [ ] Complete demo tests and obtain client approval.
- [ ] Verify live routing and fallback.

Status values: onboarding, active, paused, cancelled. Only active clients contribute to recurring-fee totals.
