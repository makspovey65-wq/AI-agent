---
type: contact
company:
role:
phone:
email:
last_contact:
next_follow_up:
do_not_contact: false
---
# {{title}}

## Notes

Record verified facts and communication preferences.
