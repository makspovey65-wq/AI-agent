---
type: interaction
date: {{date:YYYY-MM-DD}}
company:
contact:
deal:
channel: call
outcome:
next_action:
next_follow_up:
---
# {{title}}

## What actually happened

## Next steps
- [ ] Record the agreed next action.

Update linked deal/contact follow-up fields after this interaction.
