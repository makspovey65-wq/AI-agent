# Offer and Pricing

## Owner-proposed offer
| Item | Amount / status |
| --- | --- |
| One-off setup | £299 |
| Monthly service | £40 |
| Included call minutes | Proposed 60; not committed |
| Overage | Not set |
| VAT treatment | Not established |
| Contract and cancellation | Not established |

Service concept: answer incoming enquiries, capture contact details and service requests, request or make appointments where an approved booking integration works, and route exceptions to a human.

Before a client agrees, write down the supported services, hours, booking behaviour, call allowance, escalation method, support scope and all charges. Do not promise unlimited calls or guaranteed appointments.

## Economics worksheet
Enter verified provider prices before deciding the allowance. No provider prices have been checked in this vault.

Monthly contribution = £40 − allocated fixed provider costs − (used minutes × all-in variable cost/minute) − messaging costs − payment fees − other direct service costs.

All-in variable call cost must include applicable voice platform, model, transcription, speech and telephony charges without double-counting bundled components. Account for currency conversion and applicable taxes consistently. Owner support time is another cost when judging profitability.

Revenue illustration only: 10 active clients at £40 = £400/month in recurring fees before costs. Ten £299 setup fees = £2,990 one-off fees, not monthly revenue.

Do not publish the 60-minute allowance until this calculation is complete. [[Agency/Launch Checklist|Launch checklist]] tracks the decision.
