# Launch Checklist

## 1 — Establish the offer
- [ ] Choose the agency name.
- [ ] Verify access to the intended sign-up email.
- [ ] Record current provider costs and calculate margin at the proposed allowance.
- [ ] Finalise included minutes, overage, billing and cancellation terms.

## 2 — Build one working demonstration
- [ ] Record selected voice, phone, calendar and automation services in [[Agency/System Register|System Register]].
- [ ] Configure a test phone number and receptionist using an approved business profile.
- [ ] Connect a test calendar with clear availability, timezone and appointment durations.
- [ ] Configure callback handling and an owner notification destination.
- [ ] Run and record every case in [[Agency/Demo Test Plan|Demo Test Plan]].

## 3 — Prepare sales
- [ ] Import verified leads; a previously created first-40-leads spreadsheet has not been imported into this vault.
- [ ] Check each lead's business details and suitable outreach channel before contact.
- [ ] Prepare one tailored demonstration for the initial niche.
- [ ] Record each real outreach attempt and its next action.

## 4 — First customer
- [ ] Complete [[Agency/Client Onboarding|Client Onboarding]].
- [ ] Agree scope, price and terms with the client.
- [ ] Confirm required data handling and communication arrangements before launch.
- [ ] Obtain client acceptance of the tested behaviour.
- [ ] Confirm live routing and monitor the first real calls with the client.

## Next practical action
Identify what accounts or workflows already exist and update System Register. Their current status is unknown; this vault creation does not verify external setup.
