# Sales Playbook

Use these as drafts for your own conversations. No outreach has been sent by creating this vault.

## Opening call
“Hi, is this the person who handles bookings? I'm building an AI receptionist service for businesses like yours. When you're working on a car and can't pick up, how do you currently handle the enquiry?”

Listen first. Establish whether missed calls are a real problem, what services customers request, how bookings are managed and who decides about new systems.

## Short explanation
“The idea is to answer those calls, take the customer's details and service request, and help with bookings using the rules you approve. The proposed price is £299 to set up and £40 a month, with the call allowance agreed before you sign up.”

Only offer a working demonstration after it exists. Before then: “I'm preparing a demonstration; would you be interested in seeing how it could handle your enquiries?”

## Discovery questions
1. What happens to unanswered calls now?
2. Which questions and services make up most calls?
3. Do bookings need a quote, vehicle inspection, deposit or travel-area check?
4. Which calendar or booking system do you use?
5. When should a call reach you personally?
6. Who would approve this and what would a useful demo need to prove?

## Follow-up draft
“Hi [name], thanks for speaking with me. You mentioned [verified problem]. I can show how the receptionist would handle [specific enquiry]. Would [proposed time] suit a short demo? The proposed service is £299 setup and £40/month; we'll confirm the usage allowance and scope before any agreement.”

Replace bracketed text with verified details before use. A proposed meeting time is not booked until accepted.

## Pipeline stages
| Stage | Meaning |
| --- | --- |
| lead | Identified business; interest unknown |
| contacted | A real outreach attempt is recorded |
| qualified | Need and fit established |
| demo_booked | Demo time accepted |
| demo_done | Demo actually delivered |
| proposal | Specific offer provided |
| won | Client accepted the agreement |
| lost | Declined or closed with reason |

Won does not mean paid or live. Track those separately in the Client note. Keep a next action and follow-up date on every open deal. Stop outreach when asked and record the request.
