# Client Onboarding

Copy the Client template into Clients for each accepted customer. Complete the following before activating live calls.

## Business knowledge
- Trading name, approved greeting and main contact.
- Public phone number, address or mobile service area, opening hours and holiday exceptions.
- Approved services, prices, durations and vehicle-specific restrictions.
- What needs a bespoke quote rather than a fixed price.
- Booking rules, staff/resource availability, travel buffers and cancellation procedure.

## Routing and systems
- Approved call forwarding behaviour and fallback if systems fail.
- Calendar or booking service, Europe/London timezone, availability and write permissions.
- Owner escalation destination and callback expectations.
- Approved confirmation channels and wording.
- Credential references only; store secrets outside the vault.

## Acceptance
- Agree fees, allowance and service limits in writing.
- Confirm how customer data, recordings (if used), access and retention are handled.
- Test normal enquiries, unsupported requests, booking failure and human escalation.
- Obtain the client's approval of test results and exact business knowledge.
- Record the actual go-live date and first service review.

Only set status to active after live routing and the agreed service have been verified. Mark payment status using actual payment evidence.
