# System Register

As of 30 October 2026, external setup has not been inspected during this vault update. Unknown means unverified, not necessarily absent.

| Component | Status | Evidence / next step |
| --- | --- | --- |
| Agency name | Not chosen in available context | Owner decision |
| Sign-up email | Intended: maxprob@yahoo.com | Verify ownership/access |
| Voice assistant service | Unknown | Record existing account and agent ID |
| Phone provider / number | Unknown | Verify account, number and routing |
| Calendar / booking integration | Unknown | Verify read/write and timezone |
| Automation workflows | Unknown | Inspect any existing exports |
| Owner notifications | Unknown | Confirm destination and test |
| Billing / payment collection | Unknown | Confirm actual setup |
| Live receptionist | Not verified | Complete demo and routing tests |
| Lead spreadsheet | Previously created; not imported here | Import current verified contents |

Store non-secret account references and evidence here. Store API keys/passwords in a suitable credential manager or service secret store, never in exported notes.
