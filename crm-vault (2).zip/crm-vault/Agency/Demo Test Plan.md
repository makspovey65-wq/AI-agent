# Demo Test Plan

Use test data and a test calendar. None of these tests has been run. Record evidence, date and result for each before claiming the service works.

| Case | Expected behaviour | Result |
| --- | --- | --- |
| Known opening hours | Gives only approved hours | Not run |
| Unknown service price | Offers quote/callback; no invented price | Not run |
| Available appointment | Checks live availability, confirms details, writes once | Not run |
| Unavailable appointment | Offers available alternatives | Not run |
| Booking service failure | Says booking is unconfirmed and records callback | Not run |
| Duplicate booking request | Avoids duplicate writes; verifies existing result | Not run |
| Caller changes details | Repeats corrected details before booking | Not run |
| Mobile visit outside area | Follows approved area rules | Not run |
| Human requested | Uses verified transfer/fallback | Not run |
| Call drops | Handles partial request without claiming completion | Not run |
| Cancellation request | Verifies booking and follows approved procedure | Not run |
| UK clock change | Uses correct Europe/London time and explicit date | Not run |
| Notification failure | Logs failure; does not claim message delivered | Not run |

For each run record: test input, expected result, actual result, tool/booking evidence, pass/fail and correction. Never use real customer details in public demonstration recordings.
